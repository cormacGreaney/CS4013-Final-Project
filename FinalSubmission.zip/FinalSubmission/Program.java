import java.util.ArrayList;
import java.util.List;

/**
 * handles program objects
 */
public class Program {
    //Data Fields
    private String programCode;
    private String title;
    private String type;
    private int duration;
    private List<Student> students = new ArrayList<>();

    //Constructors
    /**
     * constructs a program object
     * @param programCode the program code
     * @param title the program title
     * @param type the program type
     * @param duration the program duration in years
     */
    public Program(String programCode, String title, String type, int duration) {
        this.programCode = programCode;
        this.title = title;
        this.type = type;
        this.duration = duration;
    }

    //Methods
    /**
     * populates the Students data field with associated students
     * @param allStudents all the students in the system
     */
    public void populateStudents(List<Student> allStudents) {
        for (Student student : allStudents) {
            if (student.getProgrammeCode().equals(this.getProgramCode())) {
                students.add(student);
            }
        }
    }

    /**
     * neatly displays the program details
     */
    public void viewProgramDetails() {
        System.out.println("Viewing Program Details for Program " + programCode);
        System.out.println("Title: " + title);
        System.out.println("Type: " + type);
        System.out.println("Duration: " + duration + " years");
    }

    /**
     * enrolls a student
     * @param student the student to be enrolled
     */
    public void enrollStudents(Student student) {
        System.out.println("Enrolling Student " + student.getStudentID() + " in Program " + programCode);
        students.add(student);
    }

    /**
     * neatly displays the enrolled students
     */
    public void viewEnrolledStudents() {
        System.out.println("Viewing Enrolled Students in Program " + programCode);
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentID() + ", Name: " + student.getName());
        }
    }

    /**
     * gets a program from a program code
     * @param programCode the program code
     * @param programs all the programs in the system
     * @return the associated program
     */
    public static Program getProgramById(String programCode, List<Program> programs) {
        for (Program program : programs) {
            if (program.getProgramCode().equals(programCode)) {
                return program;
            }
        }
        return null;
    }

    //Getters & Setters
    /**
     * gets the program code
     * @return the program code
     */
    public String getProgramCode() {
        return programCode;
    }

    /**
     * gets the program title
     * @return the program title
     */
    public String getTitle() {
        return title;
    }
}
