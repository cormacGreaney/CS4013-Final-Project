import java.util.List;
import java.util.Scanner;

/**
 * handles student objects
 */
public class Student {
    //Data Fields
    private String studentID;
    private String name;
    private String programmeCode;
    private int yearOfStudy;
    private String email;
    private String dateOfBirth;
    private String address;
    private String contactNo;
    private String emergencyNo;
    private String admissionDate;
    private boolean activeStudent;

    //Constructors
    /**
     * constructs a student object
     * @param studentID the students ID
     * @param name the students name
     * @param programmeCode the students associated program code
     * @param yearOfStudy the students current year of study
     * @param email the students email
     * @param dateOfBirth the students date of birth
     * @param address the students address
     * @param contactNo the students contact number
     * @param emergencyNo the students emergency contact
     * @param admissionDate the students admission date
     */
    public Student(String studentID, String name, String programmeCode, int yearOfStudy, String email,
                   String dateOfBirth, String address, String contactNo, String emergencyNo, String admissionDate) {
        this.studentID = studentID;
        this.name = name;
        this.programmeCode = programmeCode;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.admissionDate = admissionDate;
        this.activeStudent = true;
    }

    //Methods
    /**
     * neatly displays the students details
     */
    public void viewDetails() {
        System.out.println("Details for Student " + studentID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Date of Birth: " + dateOfBirth);
        System.out.println("Address: " + address);
        System.out.println("Contact No: " + contactNo);
        System.out.println("Emergency No: " + emergencyNo);
        System.out.println("Admission Date: " + admissionDate);
        System.out.println("Year of Study: " + yearOfStudy);
        System.out.println("Active Student: " + activeStudent);
    }

    /**
     * changes the students details
     */
    public void changePersonalDetails() {
        System.out.println("Changing Details for Student " + studentID);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new name: ");
        this.name = scanner.nextLine();

        System.out.print("Enter new email: ");
        this.email = scanner.nextLine();

        System.out.print("Enter new date of birth (YYYYMMDD): ");
        this.dateOfBirth = scanner.nextLine();

        System.out.print("Enter new address: ");
        this.address = scanner.nextLine();

        System.out.print("Enter new contact number: ");
        this.contactNo = scanner.nextLine();

        System.out.print("Enter new emergency contact number: ");
        this.emergencyNo = scanner.nextLine();
    }

    /**
     * drops the student out
     */
    public void dropout() {
        this.activeStudent = false;
    }

    /**
     * advances the student to next year
     */
    public void advanceToNextYear() {
        if (yearOfStudy >= 4) {
            this.activeStudent = false;
        } else yearOfStudy++;
    }

    /**
     * gets a student from a student ID
     * @param passedStudentID the student ID
     * @param students all the students in the system
     * @return the associated student
     */
    public static Student getStudentById(String passedStudentID,List<Student> students) {
        for (Student student : students) {
            if (student.getStudentID().equals(passedStudentID)) {
                return student;
            }
        }
        return null;
    }

    //Getters & Setters
    /**
     * gets the students ID
     * @return the students ID
     */
    public String getStudentID() {
        return studentID;
    }

    /**
     * gets the student name
     * @return the students name
     */
    public String getName() {
        return name;
    }

    /**
     * gets the students associated program code
     * @return the students associated program code
     */
    public String getProgrammeCode() {
        return programmeCode;
    }
}
