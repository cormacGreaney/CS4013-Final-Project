import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Handles Departments Objects
 */
public class Department {
    //Data Fields
    private String departmentCode;
    private String nameOfDepartment;
    private String headOfDepartment;
    private List<Faculty> facultyMembers;
    private List<Program> programs;
    private List<Module> modules;

    //Constructors
    /**
     * Constructs a Department
     * @param departmentCode The Department Code
     * @param nameOfDepartment The Department Name
     * @param headOfDepartment The Department Head
     * @param facultyMembers The Faculty in the Department
     * @param programs The Programs in the Department
     * @param modules The Modules in the Department
     */
    public Department(String departmentCode, String nameOfDepartment, String headOfDepartment,
                      List<Faculty> facultyMembers, List<Program> programs, List<Module> modules) {
        this.departmentCode = departmentCode;
        this.nameOfDepartment = nameOfDepartment;
        this.headOfDepartment = headOfDepartment;
        this.facultyMembers = facultyMembers;
        this.programs = programs;
        this.modules = modules;
    }

    //Methods
    /**
     * Neatly Displays the Departments Faculty Members
     */
    public void displayFacultyMembers() {
        System.out.println("Faculty Members for Department: " + nameOfDepartment + " (" + departmentCode +")");
        for (Faculty faculty : facultyMembers) {
            System.out.println("-Faculty ID: " + faculty.getFacultyID() + ", Name: " + faculty.getName());
        }
    }

    /**
     * Neatly Displays the Departments Programs
     */
    public void displayPrograms() {
        System.out.println("Programs for Department: " + nameOfDepartment + " (" + departmentCode +")");
        for (Program program : programs) {
            System.out.println("-Program Code: " + program.getProgramCode() + ", Title: " + program.getTitle());
        }
    }

    /**
     * Neatly Displays the Departments Modules
     */
    public void displayModules() {
        System.out.println("Modules for Department: " + nameOfDepartment + " (" + departmentCode +")");
        for (Module module : modules) {
            System.out.println("-Module Code: " + module.getModuleCode() + ", Title: " + module.getModuleTitle());
        }
    }

    /**
     * Populates the FacultyMembers data field
     * @param filePath The csv file containing the Faculty Members Information
     */
    public void populateFacultyMembers(String filePath) {
        List<Faculty> allFacultyMembers = CSVReader.readFacultyData(filePath);
        this.facultyMembers = allFacultyMembers.stream()
                .filter(faculty -> faculty.getDepartmentCode().equals(this.departmentCode))
                .collect(Collectors.toList());
    }

    /**
     * Populates the Programs data field
     * @param filePath The csv file containing the program information
     */
    public void populatePrograms(String filePath) {
        List<Program> allPrograms = CSVReader.readProgramData(filePath);
        this.programs = allPrograms.stream()
                .filter(program -> program.getProgramCode().startsWith(this.departmentCode))
                .collect(Collectors.toList());
    }

    /**
     * Populates the Modules data field
     * @param filePath The csv file containing the module information
     */
    public void populateModules(String filePath) {
        List<Module> allModules = CSVReader.readModuleData(filePath);
        this.modules = allModules.stream()
                .filter(module -> module.getDepartmentCode().equals(this.departmentCode))
                .collect(Collectors.toList());
    }

    /**
     * Neatly displays the department information
     */
    public void viewDepartmentDetails() {
        System.out.println("Details for Department " + departmentCode);
        System.out.println("Department Code: " + departmentCode);
        System.out.println("Department Name: " + nameOfDepartment);
        System.out.println("Head of Department: " + headOfDepartment);
    }

    /**
     * Changes the Department details
     */
    public void changeDepartmentDetails() {
        System.out.println("Changing Details for Department " + departmentCode);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new department name: ");
        this.nameOfDepartment = scanner.nextLine();

        System.out.print("Enter new head of department: ");
        this.headOfDepartment = scanner.nextLine();
    }

    /**
     * adds a faculty member to the department
     * @param facultyID the associated faculty ID
     */
    public void addFacultyMember(String facultyID) {
        facultyMembers.add(Faculty.getFacultyById(facultyID, StudentRecordsCLI.getFaculties()));
    }

    //Getters & Setters
    /**
     * Gets the department code
     * @return the department code
     */
    public String getDepartmentCode() {
        return departmentCode;
    }
}
