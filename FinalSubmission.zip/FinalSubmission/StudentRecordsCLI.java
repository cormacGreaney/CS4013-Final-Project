import java.util.List;
import java.util.Scanner;

/**
 * The command line interface
 */
public class StudentRecordsCLI {
    private List<Student> students;
    private List<Program> programs;
    private static List<Module> modules;
    private static List<Faculty> facultyMembers;
    private List<Department> departments;
    private String currentUserID;
    private String currentUserRole;
    private Student currentStudent;
    private Faculty currentFaculty;
    private Department currentDepartment;
    private ExaminationBoard currentExaminationBoard;


    /**
     * constructs a CLI with the needed data
     * @param students all students
     * @param programs all programs
     * @param modules all modules
     * @param facultyMembers all faculty
     * @param departments all departments
     */
    public StudentRecordsCLI(List<Student> students, List<Program> programs, List<Module> modules,
                             List<Faculty> facultyMembers, List<Department> departments) {
        this.students = students;
        this.programs = programs;
        this.modules = modules;
        this.facultyMembers = facultyMembers;
        this.departments = departments;
    }

    private static Scanner scanner = new Scanner(System.in);

    /**
     * Presents the login screen
     */
    public void start() {
        System.out.println("Welcome to the University of Limerick Student Records System ");

        System.out.print("Enter your ID (studentID, facultyID, or departmentCode): ");
        currentUserID = scanner.next().toUpperCase();

        determineUserRole();

        while (true) {
            switch (currentUserRole.toLowerCase()) {
                case "student":
                    studentMenu();
                    break;
                case "faculty":
                    facultyMenu();
                    break;
                case "department":
                    departmentMenu();
                    break;
                default:
                    System.out.println("Invalid role. Exiting.");
                    System.exit(0);
            }
        }
    }

    /**
     * determines the users role
     */
    private void determineUserRole() {
        for (Student student : students) {
            if (student.getStudentID().equals(currentUserID)) {
                currentUserRole = "student";
                assignCurrentStudentById();
                return;
            }
        }

        for (Faculty faculty : facultyMembers) {
            if (faculty.getFacultyID().equals(currentUserID)) {
                currentUserRole = "faculty";
                assignCurrentFacultyById();
                return;
            }
        }

        for (Department department : departments) {
            if (department.getDepartmentCode().equals(currentUserID)) {
                currentUserRole = "department";
                assignCurrentDepartmentById();
                return;
            }
        }

        System.out.println("Invalid ID. Exiting.");
        System.exit(0);
    }

    /**
     * the student menus display
     */
    private void studentMenu() {
        System.out.println("\n--- Student Menu ---");
        System.out.println("1. View Transcript");
        System.out.println("2. View Student Details");
        System.out.println("3. Change Personal Details");
        System.out.println("4. Dropout");
        System.out.println("5. Log Out");
        System.out.println("6. Exit");
        processChoice(getUserChoice());
    }

    /**
     * the faculty menus display
     */
    private void facultyMenu() {
        System.out.println("\n--- Faculty Menu ---");
        System.out.println("1. Submit Results");
        System.out.println("2. View A Student Transcript");
        System.out.println("3. View Faculty Member Details");
        System.out.println("4. Change Personal Details");
        System.out.println("5. View Taught Modules");
        System.out.println("6. View Program Details");
        System.out.println("7. View Enrolled Students");
        System.out.println("8. Enroll Students");
        System.out.println("9. Log Out");
        System.out.println("10. Exit");
        processChoice(getUserChoice());
    }

    /**
     * the department menus display
     */
    private void departmentMenu() {
        System.out.println("\n--- Department Menu ---");
        System.out.println("1. Add Faculty Member");
        System.out.println("2. View Faculty Members");
        System.out.println("3. View Programmes");
        System.out.println("4. View Modules");
        System.out.println("5. View Department Details");
        System.out.println("6. Change Department Details");
        System.out.println("7. Hold Exam Board");
        System.out.println("8. Review Student Progress");
        System.out.println("9. Log Out");
        System.out.println("10. Exit");
        processChoice(getUserChoice());
    }

    /**
     * processes the users choice
     */
    private void processChoice(int choice) {
        switch (currentUserRole.toLowerCase()) {
            case "student":
                processStudentChoice(choice);
                break;
            case "faculty":
                processFacultyChoice(choice);
                break;
            case "department":
                processDepartmentChoice(choice);
                break;
            default:
                System.out.println("Invalid role. Exiting.");
                System.exit(0);
        }
    }

    /**
     * assigns the current student based on the logged in ID
     */
    private void assignCurrentStudentById() {
        for (Student student : students) {
            if (student.getStudentID().equals(currentUserID)) {
                currentStudent = student;
            }
        }
    }

    /**
     * processes the student menus choice
     */
    private void processStudentChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Viewing Transcript...");
                Transcript transcript = new Transcript(currentUserID);
                transcript.passModules(modules);
                List<String> grades = CSVReader.readModuleResultsForStudent("moduleResults.csv", currentUserID);
                transcript.generateTranscript(grades);
                transcript.viewTranscriptDetails();
                break;
            case 2:
                System.out.println("Viewing Student Details...");
                currentStudent.viewDetails();
                break;
            case 3:
                System.out.println("Changing Personal Details...");
                currentStudent.changePersonalDetails();
                break;
            case 4:
                System.out.println("Dropping out...");
                currentStudent.dropout();
                break;
            case 5:
                this.start();
                break;
            case 6:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    /**
     * assigns the current faculty based on the logged in ID
     */
    private void assignCurrentFacultyById() {
        for (Faculty faculty : facultyMembers) {
            if (faculty.getFacultyID().equals(currentUserID)) {
                currentFaculty = faculty;
            }
        }
    }

    /**
     * processes the faculty menus choice
     */
    private void processFacultyChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Submitting Results...");
                System.out.print("Enter Module Code: ");
                String moduleEntry = scanner.next().toUpperCase();
                System.out.print("Enter Student ID: ");
                String studentEntry = scanner.next().toUpperCase();
                System.out.print("Enter Grade: ");
                String gradeEntry = scanner.next().toUpperCase();

                if (currentFaculty.getModulesTaught().contains(Module.findModuleByCode(moduleEntry, modules))) {
                    CSVWriter.writeModuleResult("moduleResults.csv", moduleEntry, studentEntry, gradeEntry);
                    System.out.println("Results submitted successfully for Student " + studentEntry + " in Module " + moduleEntry);
                } else System.out.println("You Do Not Teach This Module");
                break;
            case 2:
                System.out.println("Enter a Valid Student ID To Request a Transcript: ");
                String temp = scanner.next().toUpperCase();
                Transcript transcript = new Transcript(temp);
                transcript.passModules(modules);
                List<String> grades = CSVReader.readModuleResultsForStudent("moduleResults.csv", temp);
                transcript.generateTranscript(grades);
                transcript.viewTranscriptDetails();
                break;
            case 3:
                System.out.println("Viewing Faculty Member Details...");
                currentFaculty.viewDetails();
                break;
            case 4:
                System.out.println("Changing Personal Details...");
                currentFaculty.changePersonalDetails();
                break;
            case 5:
                System.out.println("Viewing Taught Modules...");
                currentFaculty.viewTaughtModules();
                break;
            case 6:
                System.out.println("Enter Valid Program Code: ");
                Program.getProgramById(scanner.next().toUpperCase(), programs).viewProgramDetails();
                break;
            case 7:
                System.out.println("Enter Valid Program Code: ");
                Program.getProgramById(scanner.next().toUpperCase(), programs).viewEnrolledStudents();
                break;
            case 8:
                System.out.println("Enter Valid Program Code: ");
                String program = scanner.next().toUpperCase();
                System.out.println("Enter Valid Student ID: ");
                Program.getProgramById(program, programs).enrollStudents(Student.getStudentById(scanner.next().toUpperCase(), students));
                break;
            case 9:
                this.start();
                break;
            case 10:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    /**
     * assigns the current department based on the logged in code
     */
    private void assignCurrentDepartmentById() {
        for (Department department : departments) {
            if (department.getDepartmentCode().equals(currentUserID)) {
                currentDepartment = department;
            }
        }
    }

    /**
     * processes the department menus choice
     */
    private void processDepartmentChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Enter a Valid Faculty ID: ");
                currentDepartment.addFacultyMember(scanner.next().toUpperCase());
                break;
            case 2:
                System.out.println("Viewing Department Faculty Members...");
                currentDepartment.displayFacultyMembers();
                break;
            case 3:
                System.out.println("Viewing Department Programmes...");
                currentDepartment.displayPrograms();
                break;
            case 4:
                System.out.println("Viewing Department Modules...");
                currentDepartment.displayModules();
                break;
            case 5:
                System.out.println("Viewing Department Details...");
                currentDepartment.viewDepartmentDetails();
                break;
            case 6:
                System.out.println("Changing Department Details...");
                currentDepartment.changeDepartmentDetails();
                break;
            case 7:
                System.out.println("Holding Exam Board...");
                currentExaminationBoard = new ExaminationBoard(currentDepartment);
                currentExaminationBoard.assessStudentProgress(students, modules);
                break;
            case 8:
                System.out.println("Reviewing Student Progress...");
                if (currentExaminationBoard != null) {
                    currentExaminationBoard.printPassingStudents();
                    currentExaminationBoard.printFailingStudents();
                } else System.out.println("No Examination Board Has Been Held During This Session");
                System.out.println("Do you wish to advance all Passing Students to the next year of study? (Y/N):");
                if (scanner.next().equalsIgnoreCase("Y")) {
                    System.out.println("Advancing Passing Students to Next Year...");
                    currentExaminationBoard.advancePassingStudents();
                } else System.out.println("Returning to Department Menu...");
                break;
            case 9:
                this.start();
                break;
            case 10:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    /**
     * gets the users choice
     */
    private int getUserChoice() {
        System.out.print("Enter your choice: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            System.out.print("Enter your choice: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    //Getters
    /**
     * gets the students faculty members
     * @return the systems faculty members
     */
    public static List<Faculty> getFaculties() {
        return facultyMembers;
    }
}
