import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *  Handles all the reading in of data from csv files
 */
public class CSVReader {

    /**
     * Reads in student data and constructs Student instances
     * @param filePath The student csv file
     * @return list students of all the constructed Student instances
     */
    public static List<Student> readStudentData(String filePath) {
        List<Student> students = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Student student = new Student(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]), attributes[4],
                        attributes[5], attributes[6], attributes[7], attributes[8], attributes[9]);
                students.add(student);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return students;
    }

    /**
     * Reads in program data and constructs Program instances
     * @param filePath The program csv file
     * @return list programs of all the constructed Program instances
     */
    public static List<Program> readProgramData(String filePath) {
        List<Program> programs = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Program program = new Program(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]));
                programs.add(program);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return programs;
    }

    /**
     * Reads in module data and constructs Module instances
     * @param filePath The module csv file
     * @return list modules of all the constructed Module instances
     */
    public static List<Module> readModuleData(String filePath) {
        List<Module> modules = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Module module = new Module(attributes[0], attributes[1], Integer.parseInt(attributes[2]),
                        Integer.parseInt(attributes[3]), attributes[4], attributes[5]);
                modules.add(module);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return modules;
    }

    /**
     * Reads in faculty data and constructs Faculty instances
     * @param filePath The faculty csv file
     * @return list facultyMembers of all the constructed Faculty instances
     */
    public static List<Faculty> readFacultyData(String filePath) {
        List<Faculty> facultyMembers = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Faculty faculty = new Faculty(attributes[0], attributes[1], attributes[2], null,
                        attributes[3], attributes[4], attributes[5], attributes[6], attributes[7], attributes[8]);
                facultyMembers.add(faculty);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return facultyMembers;
    }

    /**
     * Reads in department data and constructs Department instances
     * @param filePath The department csv file
     * @return list departments of all the constructed Department instances
     */
    public static List<Department> readDepartmentData(String filePath) {
        List<Department> departments = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Department department = new Department(attributes[0], attributes[1], attributes[2], null, null, null);
                departments.add(department);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return departments;
    }

    /**
     * Reads in module results data and a specific student ID, finds the results for that student
     * @param filePath The moduleResults csv file
     * @param studentID The specific student ID
     * @return list grades of all the grades for the specified student
     */
    public static List<String> readModuleResultsForStudent(String filePath, String studentID) {
        List<String> grades = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[1].equals(studentID)) {
                    grades.add(parts[0] + "," + parts[2]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return grades;
    }
}
