import java.util.List;

/**
 * handles module objects
 */
public class Module {
    //Data Fields
    private String moduleCode;
    private String moduleTitle;
    private int semester;
    private int moduleCredits;
    private String departmentCode;
    private String facultyID;


    //Constructors
    /**
     * constructs a module object
     * @param moduleCode the module code
     * @param moduleTitle the module title
     * @param semester the modules associated semester
     * @param moduleCredits the credits the module is worth
     * @param departmentCode the modules associated department code
     * @param facultyID the modules associated faculty ID
     */
    public Module(String moduleCode, String moduleTitle, int semester, int moduleCredits,
                  String departmentCode, String facultyID) {
        this.moduleCode = moduleCode;
        this.moduleTitle = moduleTitle;
        this.semester = semester;
        this.moduleCredits = moduleCredits;
        this.departmentCode = departmentCode;
        this.facultyID = facultyID;
    }

    //Methods
    /**
     * returns the module associated with a code
     * @param moduleCode the module code
     * @param modules all the modules in the system
     * @return the associated module
     */
    public static Module findModuleByCode(String moduleCode, List<Module> modules) {
        for (Module module : modules) {
            if (module.getModuleCode().equals(moduleCode)) {
                return module;
            }
        }
        return null;
    }

    //Getters & Setters
    /**
     * gets the modules code
     * @return the modules code
     */
    public String getModuleCode() {
        return moduleCode;
    }

    /**
     * gets the modules title
     * @return the modules title
     */
    public String getModuleTitle() {
        return moduleTitle;
    }

    /**
     * gets the modules associated semester
     * @return the modules associated semester
     */
    public int getSemester() {
        return semester;
    }

    /**
     * gets the modules associated department code
     * @return the modules associated department code
     */
    public String getDepartmentCode() {
        return departmentCode;
    }

    /**
     * gets the modules associated faculty ID
     * @return the modules associated faculty ID
     */
    public String getFacultyID() {
        return facultyID;
    }
}
