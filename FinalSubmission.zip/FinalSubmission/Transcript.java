import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * handles transcript objects
 */
public class Transcript {
    // Data Fields
    private String studentID;
    private Map<String, List<String>> moduleResults;
    private Map<Integer, Double> semesterQCA;
    private Map<Integer, Double> yearlyQCA;
    private double overallQCA;
    private List<Module> modules;

    // Constructors
    /**
     * constructs transcript objects
     * @param studentID the associated students ID
     */
    public Transcript(String studentID) {
        this.studentID = studentID;
        this.moduleResults = new HashMap<>();
        this.semesterQCA = new HashMap<>();
        this.yearlyQCA = new HashMap<>();
        this.overallQCA = 0.0;
    }

    // Methods
    /**
     * passes the systems modules
     */
    public void passModules(List<Module> modules) {
        this.modules = modules;
    }

    /**
     * calculates the overall QCA
     */
    public void calculateOverallQCA() {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            List<String> grades = entry.getValue();

            for (String grade : grades) {
                double qca = calculateQCA(grade);
                totalQCA += qca;
                totalModules++;
            }
        }

        if (totalModules > 0) {
            overallQCA = totalQCA / totalModules;
        }
    }

    /**
     * calculates the semester QCA
     */
    public void calculateSemesterQCA(int semester) {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            List<String> grades = entry.getValue();
            int moduleSemester = getSemesterFromModuleCode(moduleCode);

            if (moduleSemester == semester) {
                for (String grade : grades) {
                    double qca = calculateQCA(grade);
                    totalQCA += qca;
                    totalModules++;
                }
            }
        }

        if (totalModules > 0) {
            semesterQCA.put(semester, totalQCA / totalModules);
        }
    }

    /**
     * calculates the yearly qca
     */
    public void calculateYearlyQCA(int year) {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            List<String> grades = entry.getValue();
            int moduleYear = getYearFromModuleCode(moduleCode);

            if (moduleYear == year) {
                for (String grade : grades) {
                    double qca = calculateQCA(grade);
                    totalQCA += qca;
                    totalModules++;
                }
            }
        }

        if (totalModules > 0) {
            yearlyQCA.put(year, totalQCA / totalModules);
        }
    }

    /**
     * neatly displays the transcripts details
     */
    public void viewTranscriptDetails() {
        System.out.println("Viewing Transcript Details for Student " + studentID);
        System.out.println("Overall QCA: " + String.format("%.2f", overallQCA));

        for (Map.Entry<Integer, Double> entry : semesterQCA.entrySet()) {
            System.out.println("Semester " + entry.getKey() + " QCA: " + String.format("%.2f", entry.getValue()));
        }

        for (Map.Entry<Integer, Double> entry : yearlyQCA.entrySet()) {
            System.out.println("Year " + entry.getKey() + " QCA: " + String.format("%.2f", entry.getValue()));
        }
    }

    /**
     * returns the associated QCA for a grade
     * @param grade the grade
     * @return the associated QCA
     */
    private double calculateQCA(String grade) {
        switch (grade) {
            case "A1":
                return 4.00;
            case "A2":
                return 3.60;
            case "B1":
                return 3.20;
            case "B2":
                return 3.00;
            case "B3":
                return 2.80;
            case "C1":
                return 2.60;
            case "C2":
                return 2.40;
            case "C3":
                return 2.00;
            case "D1":
                return 1.60;
            case "D2":
                return 1.20;
            case "F":
                return 0.00;
            default:
                return 0.00;
        }
    }

    /**
     * gets a semester value from a module code
     * @param moduleCode the module code
     * @return the semester value
     */
    private int getSemesterFromModuleCode(String moduleCode) {
        Module module = findModuleByCode(moduleCode);

        if (module != null) {
            return module.getSemester();
        } else {
            return -1;
        }
    }

    /**
     * gets a year value from a module code
     * @param moduleCode the module code
     * @return the year value
     */
    private int getYearFromModuleCode(String moduleCode) {
        Module module = findModuleByCode(moduleCode);

        if (module != null) {
            return (module.getSemester() + 1) / 2;
        } else {
            return -1;
        }
    }

    /**
     * finds a module from a code
     * @param moduleCode the module code
     * @return the associated module
     */
    private Module findModuleByCode(String moduleCode) {
        for (Module module : modules) {
            if (module.getModuleCode().equals(moduleCode)) {
                return module;
            }
        }
        return null;
    }

    /**
     * generates a transcript by populating its data
     * @param grades the grades for a student
     */
    public void generateTranscript(List<String> grades) {
        for (String grade : grades) {
            String[] parts = grade.split(",");
            String moduleCode = parts[0];
            String gradeValue = parts[1];

            int semester = getSemesterFromModuleCode(moduleCode);
            int year = getYearFromModuleCode(moduleCode);

            updateTranscriptForModule(moduleCode, gradeValue, semester, year);
        }

        calculateOverallQCA();
        for (int semester = 1; semester <= 8; semester++) {
            calculateSemesterQCA(semester);
        }
        for (int year = 1; year <= 4; year++) {
            calculateYearlyQCA(year);
        }
    }

    /**
     * updates a transcript for a module
     * @param moduleCode the module code
     * @param gradeValue the grade value
     * @param semester the semester
     * @param year the year
     */
    private void updateTranscriptForModule(String moduleCode, String gradeValue, int semester, int year) {
        moduleResults.computeIfAbsent(moduleCode, k -> new ArrayList<>()).add(gradeValue);

        calculateSemesterQCA(semester);
        calculateYearlyQCA(year);
    }

    /**
     * gets the most recent semester
     * @return the most recent semester
     */
    public int getMostRecentSemester() {
        int mostRecentSemester = -1;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            int moduleSemester = getSemesterFromModuleCode(moduleCode);

            if (moduleSemester > mostRecentSemester) {
                mostRecentSemester = moduleSemester;
            }
        }

        return mostRecentSemester;
    }

    /**
     * checks for an F grade in a students most recent semester
     * @return true or false for a present F grade
     */
    public boolean hasFGradeInMostRecentSemester() {
        int mostRecentSemester = getMostRecentSemester();

        if (mostRecentSemester != -1) {
            for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
                String moduleCode = entry.getKey();
                int moduleSemester = getSemesterFromModuleCode(moduleCode);

                if (moduleSemester == mostRecentSemester) {
                    List<String> grades = entry.getValue();

                    for (String grade : grades) {
                        if ("F".equals(grade)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }


    /**
     * gets the semester QCA for a given semester
     * @param semester the semester
     * @return the semesters QCA
     */
    public double getSemesterQCA(int semester) {
        return semesterQCA.getOrDefault(semester, 0.0);
    }
}
