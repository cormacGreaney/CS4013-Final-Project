import java.io.FileWriter;
import java.io.IOException;

/**
 * Handles writing out of submitted results data
 */
public class CSVWriter {
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = "\r\n";


    /**
     * Writes out a submitted result to csv
     * @param fileName The csv file to be written to
     * @param moduleCode The moduleCode entry
     * @param studentID The studentID entry
     * @param grade The grade entry
     */
    public static void writeModuleResult(String fileName, String moduleCode, String studentID, String grade) {
        try (FileWriter fileWriter = new FileWriter(fileName, true)) {
            fileWriter.append(moduleCode);
            fileWriter.append(COMMA_DELIMITER);
            fileWriter.append(studentID);
            fileWriter.append(COMMA_DELIMITER);
            fileWriter.append(grade);
            fileWriter.append(NEW_LINE_SEPARATOR);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
