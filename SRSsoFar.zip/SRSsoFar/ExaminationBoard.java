import java.util.ArrayList;
import java.util.List;

public class ExaminationBoard {
    //Data Fields
    private static List<Student> passingStudents = new ArrayList<>();
    private static List<Student> failingStudents = new ArrayList<>();

    //Methods
    public static void assessStudentProgress(List<Student> students, List<Module> modules) {
        for (Student student : students) {
            Transcript transcript = new Transcript(student.getStudentID());
            transcript.passModules(modules);
            List<String> grades = CSVReader.readModuleResultsForStudent("moduleResults.csv", student.getStudentID());
            transcript.generateTranscript(grades);

            int mostRecentSemester = transcript.getMostRecentSemester();

            if (mostRecentSemester > 0) {
                transcript.calculateSemesterQCA(mostRecentSemester);

                double semesterQCA = transcript.getSemesterQCA(mostRecentSemester);
                boolean hasFGrade = transcript.hasFGradeInMostRecentSemester();

                if (semesterQCA >= 2.00 && !hasFGrade) {
                    System.out.println("Student " + student.getStudentID() + " can progress to the next year/semester.");
                    passingStudents.add(student);
                } else {
                    System.out.println("Student " + student.getStudentID() + " does not meet the minimum standards for the most recent semester.");
                    failingStudents.add(student);
                }
            } else {
                System.out.println("Student " + student.getStudentID() + " has no recorded semesters.");
            }
        }
    }

    public static void printPassingStudents() {
        System.out.println("Passing Students:");
        for (Student student : passingStudents) {
            System.out.println("Student ID: " + student.getStudentID());
        }
        System.out.println();
    }

    public static void printFailingStudents() {
        System.out.println("Failing Students:");
        for (Student student : failingStudents) {
            System.out.println("Student ID: " + student.getStudentID());
        }
        System.out.println();
    }
}
