import java.util.Scanner;

public class Student {
    //Data Fields
    private String studentID;
    private String name;
    private String programmeCode;
    private int yearOfStudy;
    private String email;
    private String dateOfBirth;
    private String address;
    private String contactNo;
    private String emergencyNo;
    private String admissionDate;

    //Constructors
    public Student(String studentID, String name, String programmeCode, int yearOfStudy, String email,
                   String dateOfBirth, String address, String contactNo, String emergencyNo, String admissionDate) {
        this.studentID = studentID;
        this.name = name;
        this.programmeCode = programmeCode;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.admissionDate = admissionDate;
    }

    //Methods
    public void viewDetails() {
        System.out.println("Details for Student " + studentID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Date of Birth: " + dateOfBirth);
        System.out.println("Address: " + address);
        System.out.println("Contact No: " + contactNo);
        System.out.println("Emergency No: " + emergencyNo);
        System.out.println("Admission Date: " + admissionDate);
    }

    public void changePersonalDetails() {
        System.out.println("Changing Details for Student " + studentID);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new name: ");
        this.name = scanner.nextLine();

        System.out.print("Enter new email: ");
        this.email = scanner.nextLine();

        System.out.print("Enter new date of birth (YYYYMMDD): ");
        this.dateOfBirth = scanner.nextLine();

        System.out.print("Enter new address: ");
        this.address = scanner.nextLine();

        System.out.print("Enter new contact number: ");
        this.contactNo = scanner.nextLine();

        System.out.print("Enter new emergency contact number: ");
        this.emergencyNo = scanner.nextLine();
    }

    //Getters & Setters
    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }
}
