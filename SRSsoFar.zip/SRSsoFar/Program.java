import java.util.List;

public class Program {
    //Data Fields
    private String programCode;
    private String title;
    private String type;
    private int duration;
    private List<Module> requiredModules;
    private List<Module> electedModules;
    private List<Student> students;
    private List<Faculty> faculty;

    //Constructors
    public Program(String programCode, String title, String type, int duration,
                   List<Module> requiredModules, List<Module> electedModules,
                   List<Student> students, List<Faculty> faculty) {
        this.programCode = programCode;
        this.title = title;
        this.type = type;
        this.duration = duration;
        this.requiredModules = requiredModules;
        this.electedModules = electedModules;
        this.students = students;
        this.faculty = faculty;
    }

    //Methods
    public void viewProgramDetails() {
        System.out.println("Viewing Program Details for Program " + programCode);
        System.out.println("Title: " + title);
        System.out.println("Type: " + type);
        System.out.println("Duration: " + duration + " years");
    }

    public void enrollStudents(List<Student> newStudents) {
        System.out.println("Enrolling Students in Program " + programCode);
        students.addAll(newStudents);
    }

    public void viewEnrolledStudents() {
        System.out.println("Viewing Enrolled Students in Program " + programCode);
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentID() + ", Name: " + student.getName());
        }
    }

    //Getters & Setters
    public String getProgramCode() {
        return programCode;
    }

    public String getTitle() {
        return title;
    }


}
