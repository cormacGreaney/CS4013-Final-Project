import java.util.List;
import java.util.Map;

public class StudentRecordsApp {

    public static void main(String[] args) {
        List<Student> students = CSVReader.readStudentData("students.csv");
        List<Program> programs = CSVReader.readProgramData("programs.csv");
        List<Module> modules = CSVReader.readModuleData("modules.csv");
        List<Faculty> facultyMembers = CSVReader.readFacultyData("faculty.csv");
        List<Department> departments = CSVReader.readDepartmentData("departments.csv");
        Map<String, List<String>> moduleResults = CSVReader.readModuleResults("moduleResults.csv");

        for (Department department : departments) {
            department.populateFacultyMembers("faculty.csv");
            department.populatePrograms("programs.csv");
            department.populateModules("modules.csv");
        }

        StudentRecordsCLI cli = new StudentRecordsCLI(students, programs, modules, facultyMembers, departments, moduleResults);
        cli.start();
    }
}