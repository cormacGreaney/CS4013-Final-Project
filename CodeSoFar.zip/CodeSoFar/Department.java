import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Department {
    //Data Fields
    private String departmentCode;
    private String nameOfDepartment;
    private String headOfDepartment;
    private List<Faculty> facultyMembers;
    private List<Program> programs;
    private List<Module> modules;

    //Constructors
    public Department(String departmentCode, String nameOfDepartment, String headOfDepartment,
                      List<Faculty> facultyMembers, List<Program> programs, List<Module> modules) {
        this.departmentCode = departmentCode;
        this.nameOfDepartment = nameOfDepartment;
        this.headOfDepartment = headOfDepartment;
        this.facultyMembers = facultyMembers;
        this.programs = programs;
        this.modules = modules;
    }

    //Methods
    public void viewDepartmentDetails() {
        System.out.println("Details for Department " + departmentCode);
        System.out.println("Department Code: " + departmentCode);
        System.out.println("Department Name: " + nameOfDepartment);
        System.out.println("Head of Department: " + headOfDepartment);
    }

    public void changeDepartmentDetails() {
        System.out.println("Changing Details for Department " + departmentCode);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new department name: ");
        this.nameOfDepartment = scanner.nextLine();

        System.out.print("Enter new head of department: ");
        this.headOfDepartment = scanner.nextLine();
    }


    //Getters & Setters
    public String getDepartmentCode() {
        return departmentCode;
    }
}
