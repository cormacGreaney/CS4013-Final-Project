import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CSVReader {

    public static List<Student> readStudentData(String filePath) {
        List<Student> students = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Student student = new Student(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]), attributes[4],
                        attributes[5], attributes[6], attributes[7], attributes[8], attributes[9]);
                students.add(student);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return students;
    }

    public static List<Program> readProgramData(String filePath) {
        List<Program> programs = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Program program = new Program(attributes[0], attributes[1], attributes[2], Integer.parseInt(attributes[3]), null, null, null, null);
                programs.add(program);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return programs;
    }

    public static List<Module> readModuleData(String filePath) {
        List<Module> modules = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Module module = new Module(attributes[0], attributes[1], Integer.parseInt(attributes[2]),
                        Integer.parseInt(attributes[3]), attributes[4], attributes[5]);
                modules.add(module);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return modules;
    }

    public static List<Faculty> readFacultyData(String filePath) {
        List<Faculty> faculties = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Faculty faculty = new Faculty(attributes[0], attributes[1], attributes[2], null,
                        attributes[3], attributes[4], attributes[5], attributes[6], attributes[7], attributes[8]);
                faculties.add(faculty);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return faculties;
    }

    public static List<Department> readDepartmentData(String filePath) {
        List<Department> departments = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                Department department = new Department(attributes[0], attributes[1], attributes[2], null, null, null);
                departments.add(department);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return departments;
    }

    public static Map<String, List<String>> readModuleResults(String filePath) {
        Map<String, List<String>> moduleResults = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] attributes = line.split(",");
                String moduleCode = attributes[0];
                String studentID = attributes[1];
                String grade = attributes[2];
                moduleResults.computeIfAbsent(moduleCode, k -> new ArrayList<>());
                moduleResults.get(moduleCode).add(studentID + "," + grade);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return moduleResults;
    }

    public static List<String> readModuleResultsForStudent(String filePath, String studentID) {
        List<String> grades = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[1].equals(studentID)) {
                    grades.add(parts[0] + "," + parts[2]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return grades;
    }
}
