import java.util.List;
import java.util.Scanner;

public class Faculty {
    //Data Fields
    private String facultyID;
    private String name;
    private String departmentCode;
    private List<Module> modulesTaught;
    private String email;
    private String contactNo;
    private String emergencyNo;
    private String officeLocation;
    private String officeHours;
    private String dateOfBirth;

    //Constructors
    public Faculty(String facultyID, String name, String departmentCode, List<Module> modulesTaught,
                   String email, String contactNo, String emergencyNo, String officeLocation,
                   String officeHours, String dateOfBirth) {
        this.facultyID = facultyID;
        this.name = name;
        this.departmentCode = departmentCode;
        this.modulesTaught = modulesTaught;
        this.email = email;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.officeLocation = officeLocation;
        this.officeHours = officeHours;
        this.dateOfBirth = dateOfBirth;
    }

    //Methods
    public void viewPersonalDetails() {
        System.out.println("Personal Details for Faculty Member " + facultyID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Contact No: " + contactNo);
        System.out.println("Emergency No: " + emergencyNo);
        System.out.println("Office Location: " + officeLocation);
        System.out.println("Office Hours: " + officeHours);
        System.out.println("Date of Birth: " + dateOfBirth);
    }

    public void changePersonalDetails() {
        System.out.println("Changing Details for Faculty Member " + facultyID);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new name: ");
        this.name = scanner.nextLine();

        System.out.print("Enter new email: ");
        this.email = scanner.nextLine();

        System.out.print("Enter new contact number: ");
        this.contactNo = scanner.nextLine();

        System.out.print("Enter new emergency contact number: ");
        this.emergencyNo = scanner.nextLine();

        System.out.print("Enter new office location: ");
        this.officeLocation = scanner.nextLine();

        System.out.print("Enter new office hours: ");
        this.officeHours = scanner.nextLine();

        System.out.print("Enter new date of birth (YYYYMMDD): ");
        this.dateOfBirth = scanner.nextLine();
    }

    //Getters & Setters
    public String getFacultyID() {
        return facultyID;
    }

    public String getName() {
        return name;
    }
}
