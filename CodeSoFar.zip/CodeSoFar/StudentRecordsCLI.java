import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class StudentRecordsCLI {
    private List<Student> students;
    private List<Program> programs;
    private List<Module> modules;
    private List<Faculty> faculties;
    private List<Department> departments;
    private Map<String, List<String>> moduleResults;
    private String currentUserID;
    private String currentUserRole;
    private Student currentStudent;
    private Faculty currentFaculty;
    private Department currentDepartment;

    public StudentRecordsCLI(List<Student> students, List<Program> programs, List<Module> modules,
                             List<Faculty> faculties, List<Department> departments,
                             Map<String, List<String>> moduleResults) {
        this.students = students;
        this.programs = programs;
        this.modules = modules;
        this.faculties = faculties;
        this.departments = departments;
        this.moduleResults = moduleResults;
    }

    private static Scanner scanner = new Scanner(System.in);

    public void start() {
        System.out.println("Welcome to the University of Limerick Student Records System ");

        System.out.print("Enter your ID (studentID, facultyID, or departmentCode): ");
        currentUserID = scanner.next();

        determineUserRole();

        while (true) {
            switch (currentUserRole.toLowerCase()) {
                case "student":
                    studentMenu();
                    break;
                case "faculty":
                    facultyMenu();
                    break;
                case "department":
                    departmentMenu();
                    break;
                default:
                    System.out.println("Invalid role. Exiting.");
                    System.exit(0);
            }
        }
    }

    private void determineUserRole() {
        for (Student student : students) {
            if (student.getStudentID().equals(currentUserID)) {
                currentUserRole = "student";
                assignCurrentStudentById();
                return;
            }
        }

        for (Faculty faculty : faculties) {
            if (faculty.getFacultyID().equals(currentUserID)) {
                currentUserRole = "faculty";
                assignCurrentFacultyById();
                return;
            }
        }

        for (Department department : departments) {
            if (department.getDepartmentCode().equals(currentUserID)) {
                currentUserRole = "department";
                assignCurrentDepartmentById();
                return;
            }
        }

        System.out.println("Invalid ID. Exiting.");
        System.exit(0);
    }

    private void studentMenu() {
        System.out.println("\n--- Student Menu ---");
        System.out.println("1. View Transcript");
        System.out.println("2. Enroll in Module");
        System.out.println("3. Repeat Module");
        System.out.println("4. View Personal Details");
        System.out.println("5. Change Personal Details");
        System.out.println("6. Exit");
        processChoice(getUserChoice());
    }

    private void facultyMenu() {
        System.out.println("\n--- Faculty Menu ---");
        System.out.println("1. Submit Results");
        System.out.println("2. View Transcript");
        System.out.println("3. View Personal Details");
        System.out.println("4. Change Personal Details");
        System.out.println("5. Exit");
        processChoice(getUserChoice());
    }

    private void departmentMenu() {
        System.out.println("\n--- Department Menu ---");
        System.out.println("1. Add Faculty Member");
        System.out.println("2. View Faculty Members");
        System.out.println("3. View Programmes");
        System.out.println("4. View Modules");
        System.out.println("5. View Department Details");
        System.out.println("6. Change Department Details");
        System.out.println("7. Hold Exam Board");
        System.out.println("8. Review Student Progress");
        System.out.println("9. Exit");
        processChoice(getUserChoice());
    }

    private void processChoice(int choice) {
        switch (currentUserRole.toLowerCase()) {
            case "student":
                processStudentChoice(choice);
                break;
            case "faculty":
                processFacultyChoice(choice);
                break;
            case "department":
                processDepartmentChoice(choice);
                break;
            default:
                System.out.println("Invalid role. Exiting.");
                System.exit(0);
        }
    }

    private void assignCurrentStudentById() {
        for (Student student : students) {
            if (student.getStudentID().equals(currentUserID)) {
                currentStudent = student;
            }
        }
    }

    private void processStudentChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Viewing Transcript...");
                Transcript transcript = new Transcript(currentUserID);
                transcript.passModules(modules);
                List<String> grades = CSVReader.readModuleResultsForStudent("moduleResults.csv", currentUserID);
                transcript.generateTranscript(grades);
                break;
            case 2:
                System.out.println("Enter the Module Code:");
                currentStudent.enrollInModule(scanner.nextLine(), modules);
                break;
            case 3:
                System.out.println("Repeating Module...");
                break;
            case 4:
                System.out.println("Viewing Personal Details...");
                currentStudent.viewPersonalDetails();
                break;
            case 5:
                System.out.println("Changing Personal Details...");
                currentStudent.changePersonalDetails();
                break;
            case 6:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void assignCurrentFacultyById() {
        for (Faculty faculty : faculties) {
            if (faculty.getFacultyID().equals(currentUserID)) {
                currentFaculty = faculty;
            }
        }
    }

    private void processFacultyChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Submitting Results...");
                break;
            case 2:
                System.out.println("Viewing Transcript...");
                break;
            case 3:
                System.out.println("Viewing Personal Details...");
                currentFaculty.viewPersonalDetails();
                break;
            case 4:
                System.out.println("Changing Personal Details...");
                currentFaculty.changePersonalDetails();
                break;
            case 5:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void assignCurrentDepartmentById() {
        for (Department department : departments) {
            if (department.getDepartmentCode().equals(currentUserID)) {
                currentDepartment = department;
            }
        }
    }

    private void processDepartmentChoice(int choice) {
        switch (choice) {
            case 1:
                System.out.println("Adding Faculty Member...");
                break;
            case 2:
                System.out.println("Viewing Faculty Members...");
                break;
            case 3:
                System.out.println("Viewing Programmes...");
                break;
            case 4:
                System.out.println("Viewing Modules...");
                break;
            case 5:
                System.out.println("Viewing Department Details...");
                currentDepartment.viewDepartmentDetails();
                break;
            case 6:
                System.out.println("Changing Department Details...");
                currentDepartment.changeDepartmentDetails();
                break;
            case 7:
                System.out.println("Holding Exam Board...");
                break;
            case 8:
                System.out.println("Reviewing Student Progress...");
                break;
            case 9:
                System.out.println("Exiting Student Records System");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private int getUserChoice() {
        System.out.print("Enter your choice: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            System.out.print("Enter your choice: ");
            scanner.next();
        }
        return scanner.nextInt();
    }

    //Getters
    public List<Module> getModules() {
        return modules;
    }
}
