import java.util.List;

public class PostgraduateProgram extends Program {
    public PostgraduateProgram(String programCode, String title, int duration,
                               List<Module> requiredModules, List<Module> electedModules,
                               List<Student> students, List<Faculty> faculty) {
        super(programCode, title, "Postgraduate", duration, requiredModules, electedModules, students, faculty);
    }
}
