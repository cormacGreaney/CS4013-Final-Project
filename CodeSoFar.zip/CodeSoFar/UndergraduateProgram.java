import java.util.List;

public class UndergraduateProgram extends Program {
    public UndergraduateProgram(String programCode, String title, int duration,
                                List<Module> requiredModules, List<Module> electedModules,
                                List<Student> students, List<Faculty> faculty) {
        super(programCode, title, "Undergraduate", duration, requiredModules, electedModules, students, faculty);
    }
}
