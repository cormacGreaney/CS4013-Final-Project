import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Student {
    //Data Fields
    private String studentID;
    private String name;
    private String programmeCode;
    private int yearOfStudy;
    private String email;
    private String dateOfBirth;
    private String address;
    private String contactNo;
    private String emergencyNo;
    private String admissionDate;
    private Map<String, List<String>> moduleResults;
    private List<Module> enrolledModules;

    //Constructors
    public Student(String studentID, String name, String programmeCode, int yearOfStudy, String email,
                   String dateOfBirth, String address, String contactNo, String emergencyNo, String admissionDate) {
        this.studentID = studentID;
        this.name = name;
        this.programmeCode = programmeCode;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.admissionDate = admissionDate;
        this.moduleResults = new HashMap<>();
    }

    //Methods
    public void enrollInModule(String moduleCode, List<Module> modules) {
        Module module = Module.findModuleByCode(moduleCode, modules);

        if (module != null) {
            enrolledModules.add(module);
            System.out.println("Enrolled in module: " + moduleCode);
        } else {
            System.out.println("Module not found with code: " + moduleCode);
        }
    }

    public void repeatModule(Module module) {
        System.out.println("Repeating Module " + module.getModuleCode() + " for Student " + studentID);
        module.enrollStudent(this);
    }

    public void viewPersonalDetails() {
        System.out.println("Personal Details for Student " + studentID);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Date of Birth: " + dateOfBirth);
        System.out.println("Address: " + address);
        System.out.println("Contact No: " + contactNo);
        System.out.println("Emergency No: " + emergencyNo);
    }

    public void changePersonalDetails() {
        System.out.println("Changing Details for Student " + studentID);
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter new name: ");
        this.name = scanner.nextLine();

        System.out.print("Enter new email: ");
        this.email = scanner.nextLine();

        System.out.print("Enter new date of birth (YYYYMMDD): ");
        this.dateOfBirth = scanner.nextLine();

        System.out.print("Enter new address: ");
        this.address = scanner.nextLine();

        System.out.print("Enter new contact number: ");
        this.contactNo = scanner.nextLine();

        System.out.print("Enter new emergency contact number: ");
        this.emergencyNo = scanner.nextLine();
    }

    //Getters & Setters
    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }
}
