import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Module {
    //Data Fields
    private String moduleCode;
    private String moduleTitle;
    private int semester;
    private int moduleCredits;
    private String departmentCode;
    private String facultyID;
    private List<String> enrolledStudents;
    private Map<String, List<String>> moduleResults;

    //Constructors
    public Module(String moduleCode, String moduleTitle, int semester, int moduleCredits,
                  String departmentCode, String facultyID) {
        this.moduleCode = moduleCode;
        this.moduleTitle = moduleTitle;
        this.semester = semester;
        this.moduleCredits = moduleCredits;
        this.departmentCode = departmentCode;
        this.facultyID = facultyID;
        this.enrolledStudents = new ArrayList<>();
    }

    //Methods
    public void enrollStudent(Student student) {
        System.out.println("Enrolling Student " + student.getStudentID() + " in Module " + moduleCode);
        enrolledStudents.add(student.getStudentID() + ",NA");
    }

    public static Module findModuleByCode(String moduleCode, List<Module> modules) {
        for (Module module : modules) {
            if (module.getModuleCode().equals(moduleCode)) {
                return module;
            }
        }
        return null;
    }

    //Getters & Setters
    public String getModuleCode() {
        return moduleCode;
    }

    public String getModuleTitle() {
        return moduleTitle;
    }

    public int getSemester() {
        return semester;
    }
}
