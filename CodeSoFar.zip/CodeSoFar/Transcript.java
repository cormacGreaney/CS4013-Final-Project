import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Transcript {
    // Data Fields
    private String studentID;
    private Map<String, List<String>> moduleResults;
    private Map<Integer, Double> semesterQCA;
    private Map<Integer, Double> yearlyQCA;
    private double overallQCA;
    private List<Module> modules;

    // Constructors
    public Transcript(String studentID) {
        this.studentID = studentID;
        this.moduleResults = new HashMap<>();
        this.semesterQCA = new HashMap<>();
        this.yearlyQCA = new HashMap<>();
        this.overallQCA = 0.0;
    }

    // Methods

    public void passModules(List<Module> modules) {
        this.modules = modules;
    }

    public void calculateOverallQCA() {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            List<String> grades = entry.getValue();

            for (String grade : grades) {
                double qca = calculateQCA(grade);
                totalQCA += qca;
                totalModules++;
            }
        }

        if (totalModules > 0) {
            overallQCA = totalQCA / totalModules;
        }
    }

    public void calculateSemesterQCA(int semester) {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            List<String> grades = entry.getValue();
            int moduleSemester = getSemesterFromModuleCode(moduleCode);

            if (moduleSemester == semester) {
                for (String grade : grades) {
                    double qca = calculateQCA(grade);
                    totalQCA += qca;
                    totalModules++;
                }
            }
        }

        if (totalModules > 0) {
            semesterQCA.put(semester, totalQCA / totalModules);
        }
    }

    public void calculateYearlyQCA(int year) {
        int totalModules = 0;
        double totalQCA = 0.0;

        for (Map.Entry<String, List<String>> entry : moduleResults.entrySet()) {
            String moduleCode = entry.getKey();
            List<String> grades = entry.getValue();
            int moduleYear = getYearFromModuleCode(moduleCode);

            if (moduleYear == year) {
                for (String grade : grades) {
                    double qca = calculateQCA(grade);
                    totalQCA += qca;
                    totalModules++;
                }
            }
        }

        if (totalModules > 0) {
            yearlyQCA.put(year, totalQCA / totalModules);
        }
    }

    public void viewTranscriptDetails() {
        System.out.println("Viewing Transcript Details for Student " + studentID);
        System.out.println("Overall QCA: " + overallQCA);

        for (Map.Entry<Integer, Double> entry : semesterQCA.entrySet()) {
            System.out.println("Semester " + entry.getKey() + " QCA: " + entry.getValue());
        }

        for (Map.Entry<Integer, Double> entry : yearlyQCA.entrySet()) {
            System.out.println("Year " + entry.getKey() + " QCA: " + entry.getValue());
        }
    }

    private double calculateQCA(String grade) {
        switch (grade) {
            case "A1":
                return 4.00;
            case "A2":
                return 3.60;
            case "B1":
                return 3.20;
            case "B2":
                return 3.00;
            case "B3":
                return 2.80;
            case "C1":
                return 2.60;
            case "C2":
                return 2.40;
            case "C3":
                return 2.00;
            case "D1":
                return 1.60;
            case "D2":
                return 1.20;
            case "F":
                return 0.00;
            default:
                return 0.00;
        }
    }

    private int getSemesterFromModuleCode(String moduleCode) {
        Module module = findModuleByCode(moduleCode);

        if (module != null) {
            return module.getSemester();
        } else {
            return -1;
        }
    }

    private int getYearFromModuleCode(String moduleCode) {
        Module module = findModuleByCode(moduleCode);

        if (module != null) {
            return (module.getSemester() + 1) / 2;
        } else {
            return -1;
        }
    }

    private Module findModuleByCode(String moduleCode) {
        for (Module module : modules) {
            if (module.getModuleCode().equals(moduleCode)) {
                return module;
            }
        }
        return null;
    }

    public void generateTranscript(List<String> grades) {
        for (String grade : grades) {
            String[] parts = grade.split(",");
            String moduleCode = parts[0];
            String gradeValue = parts[1];

            int semester = getSemesterFromModuleCode(moduleCode);
            int year = getYearFromModuleCode(moduleCode);

            updateTranscriptForModule(moduleCode, gradeValue, semester, year);
        }

        calculateOverallQCA();
        for (int semester = 1; semester <= 8; semester++) {
            calculateSemesterQCA(semester);
        }
        for (int year = 1; year <= 4; year++) {
            calculateYearlyQCA(year);
        }

        viewTranscriptDetails();
    }

    private void updateTranscriptForModule(String moduleCode, String gradeValue, int semester, int year) {
        moduleResults.computeIfAbsent(moduleCode, k -> new ArrayList<>()).add(gradeValue);

        calculateSemesterQCA(semester);
        calculateYearlyQCA(year);
    }

    // Getters & Setters
    public String getStudentID() {
        return studentID;
    }
}
