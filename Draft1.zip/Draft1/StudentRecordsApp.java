import java.util.List;

public class StudentRecordsApp {

    public static void main(String[] args) {
        List<Student> students = CSVReader.readStudentData("students.csv");
        List<Program> programs = CSVReader.readProgramData("programs.csv");
        List<Module> modules = CSVReader.readModuleData("modules.csv");
        List<Faculty> faculties = CSVReader.readFacultyData("faculties.csv");
        List<Department> departments = CSVReader.readDepartmentData("departments.csv");

        StudentRecordsCLI cli = new StudentRecordsCLI();
        cli.start();
    }
}
