public class Transcript {
    private String studentID;
    private double overallQCA;
    private double semesterQCA;
    private double yearlyQCA;

    public Transcript(String studentID, double overallQCA, double semesterQCA, double yearlyQCA) {
        this.studentID = studentID;
        this.overallQCA = overallQCA;
        this.semesterQCA = semesterQCA;
        this.yearlyQCA = yearlyQCA;
    }

    public void calculateOverallQCA() {
        // Implementation
    }

    public void calculateSemesterQCA() {
        // Implementation
    }

    public void calculateYearlyQCA() {
        // Implementation
    }

    public void viewTranscriptDetails() {
        // Implementation
    }
}
