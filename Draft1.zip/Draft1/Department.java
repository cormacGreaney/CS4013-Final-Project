import java.util.List;

public class Department {
    private String departmentCode;
    private String nameOfDepartment;
    private String headOfDepartment;
    private List<Faculty> facultyList;
    private List<Program> programList;
    private List<Module> moduleList;

    public Department(String departmentCode, String nameOfDepartment, String headOfDepartment,
                      List<Faculty> facultyList, List<Program> programList, List<Module> moduleList) {
        this.departmentCode = departmentCode;
        this.nameOfDepartment = nameOfDepartment;
        this.headOfDepartment = headOfDepartment;
        this.facultyList = facultyList;
        this.programList = programList;
        this.moduleList = moduleList;
    }

    public void addFacultyMember(Faculty faculty) {
        // Implementation
    }

    public void viewFacultyMember() {
        // Implementation
    }
}
