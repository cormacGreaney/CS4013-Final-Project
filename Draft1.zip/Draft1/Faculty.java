import java.util.List;

public class Faculty {
    private String facultyID;
    private String name;
    private String departmentCode;
    private List<Module> modulesTaught;
    private String email;
    private String contactNo;
    private String emergencyNo;
    private String officeLocation;
    private String officeHours;
    private String dateOfBirth;

    public Faculty(String facultyID, String name, String departmentCode, List<Module> modulesTaught,
                   String email, String contactNo, String emergencyNo, String officeLocation,
                   String officeHours, String dateOfBirth) {
        this.facultyID = facultyID;
        this.name = name;
        this.departmentCode  = departmentCode;
        this.modulesTaught = modulesTaught;
        this.email = email;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.officeLocation = officeLocation;
        this.officeHours = officeHours;
        this.dateOfBirth = dateOfBirth;
    }

    public void submitResults(Module module, List<Student> students, List<String> grades) {
        // Implementation
    }

    public void viewTranscript(Student student) {
        // Implementation
    }

    public void viewTeachingSchedule() {
        // Implementation
    }

    public void viewPersonalDetails() {
        // Implementation
    }

    public void changePersonalDetails() {
        // Implementation
    }
}
