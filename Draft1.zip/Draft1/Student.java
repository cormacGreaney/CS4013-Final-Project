import java.util.List;

public class Student {
    private String studentID;
    private String name;
    private String programmeCode;
    private int yearOfStudy;
    private String email;
    private String dateOfBirth;
    private String address;
    private String contactNo;
    private String emergencyNo;
    private String admissionDate;

    public Student(String studentID, String name, String programmeCode, int yearOfStudy, String email,
                   String dateOfBirth, String address, String contactNo, String emergencyNo, String admissionDate) {
        this.studentID = studentID;
        this.name = name;
        this.programmeCode = programmeCode;
        this.yearOfStudy = yearOfStudy;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.contactNo = contactNo;
        this.emergencyNo = emergencyNo;
        this.admissionDate = admissionDate;
    }

    public void viewTranscript() {
        // Implementation
    }

    public void enrollInModule(Module module) {
        // Implementation
    }

    public void repeatModule(Module module) {
        // Implementation
    }

    public void viewPersonalDetails() {
        // Implementation
    }

    public void changePersonalDetails() {
        // Implementation
    }
}
