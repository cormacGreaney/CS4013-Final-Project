import java.util.List;

public class Module {
    private String moduleCode;
    private String moduleTitle;
    private int semester;
    private int moduleCredits;
    private Department department;
    private Faculty instructor;
    private List<Student> enrolledStudents;

    public Module(String moduleCode, String moduleTitle, int semester, int moduleCredits,
                  Department department, Faculty instructor, List<Student> enrolledStudents) {
        this.moduleCode = moduleCode;
        this.moduleTitle = moduleTitle;
        this.semester = semester;
        this.moduleCredits = moduleCredits;
        this.department = department;
        this.instructor = instructor;
        this.enrolledStudents = enrolledStudents;
    }

    public void submitResults(List<Student> students, List<String> grades) {
        // Implementation
    }

    public void viewResults() {
        // Implementation
    }

    public void viewEnrolledResults() {
        // Implementation
    }

    public void calculateQCA() {
        // Implementation
    }

    public void moduleDetails() {
        // Implementation
    }
}
