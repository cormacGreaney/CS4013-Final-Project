import java.util.List;

public class Program {
    private String programCode;
    private String title;
    private String type;
    private int duration;
    private List<Module> requiredModules;
    private List<Module> electedModules;
    private List<Student> students;
    private List<Faculty> facultyList;

    public Program(String programCode, String title, String type, int duration,
                   List<Module> requiredModules, List<Module> electedModules,
                   List<Student> students, List<Faculty> facultyList) {
        this.programCode = programCode;
        this.title = title;
        this.type = type;
        this.duration = duration;
        this.requiredModules = requiredModules;
        this.electedModules = electedModules;
        this.students = students;
        this.facultyList = facultyList;
    }

    public void viewProgramDetails() {
        // Implementation
    }

    public void enrollStudents(List<Student> students) {
        // Implementation
    }

    public void viewEnrolledStudents() {
        // Implementation
    }

    public void viewModules() {
        // Implementation
    }

    public void editDetails() {
        // Implementation
    }
}
