import java.util.Scanner;

public class StudentRecordsCLI {

    private static Scanner scanner = new Scanner(System.in);

    public void start() {
        System.out.println("Welcome to the University of Limerick Student Records System ");

        while (true) {
            printMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    //Implementation
                    System.out.println("Viewing Transcript...");
                    break;
                case 2:
                    //Implementation
                    System.out.println("Enrolling in Module...");
                    break;
                case 3:
                    //Implementation
                    System.out.println("Repeating Module...");
                    break;
                case 4:
                    //Implementation
                    System.out.println("Viewing Personal Details...");
                    break;
                case 5:
                    //Implementation
                    System.out.println("Changing Personal Details...");
                    break;
                case 6:
                    System.out.println("Closing Exiting Student Records System");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. View Transcript");
        System.out.println("2. Enroll in Module");
        System.out.println("3. Repeat Module");
        System.out.println("4. View Personal Details");
        System.out.println("5. Change Personal Details");
        System.out.println("6. Exit");
    }

    private static int getUserChoice() {
        System.out.print("Enter your choice: ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            System.out.print("Enter your choice: ");
            scanner.next();
        }
        return scanner.nextInt();
    }
}
